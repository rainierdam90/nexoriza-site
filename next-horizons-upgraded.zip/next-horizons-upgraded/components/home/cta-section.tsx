import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Calendar } from "lucide-react"

export function CTASection() {
  return (
    <section className="relative overflow-hidden py-24">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-600" />
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: "32px 32px"
        }}
      />
      
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl">
            Ready to Move Faster Than Your Competition?
          </h2>
          <p className="mt-6 text-lg text-white/80 max-w-xl mx-auto">
            Whether you need a website that converts or compliance that scales — we can have your first concept or demo ready within 48 hours.
          </p>
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button
              asChild
              size="lg"
              className="group bg-white text-blue-600 hover:bg-white/90 shadow-lg"
            >
              <Link href="/contact">
                Get in Touch Today
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
            >
              <Link href="/contact">
                <Calendar className="mr-2 h-4 w-4" />
                Book a Free 30-Min Call
              </Link>
            </Button>
          </div>
          <p className="mt-6 text-sm text-white/60">No commitment required · Response within 24 hours</p>
        </div>
      </div>
    </section>
  )
}
