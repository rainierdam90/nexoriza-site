import { Cpu, Layers, Zap, Building2, ShieldCheck, Settings } from "lucide-react"

const features = [
  {
    icon: Cpu,
    title: "Powered by GPT-4, Claude & Beyond",
    description: "We use the most capable AI models available — selecting the right tool for each task to maximise quality and speed.",
  },
  {
    icon: Layers,
    title: "Enterprise-Ready Architecture",
    description: "Every solution we build is designed to scale — from a 5-person startup to a 5,000-person institution.",
  },
  {
    icon: Zap,
    title: "Fast. Really Fast.",
    description: "First design concept in 48 hours. Full CDD report in under 10 minutes. We believe speed and quality are not trade-offs.",
  },
  {
    icon: Building2,
    title: "Built for Regulated Industries",
    description: "Our due diligence platform is built with banks, asset managers, and compliance teams in mind — not adapted after the fact.",
  },
  {
    icon: ShieldCheck,
    title: "Compliance-First by Design",
    description: "GDPR-compliant, FATF-aligned, and built with audit-ready outputs. We don't bolt on compliance — we start with it.",
  },
  {
    icon: Settings,
    title: "Tailored, Not Templated",
    description: "No cookie-cutter solutions. Every website and every compliance workflow is custom-built to your specific needs and brand.",
  },
]

export function WhySection() {
  return (
    <section className="relative bg-foreground/[0.02] py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">Why Next Horizons</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            The Difference Is in the Detail
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            We combine deep AI expertise with real industry experience. The result? Solutions that actually work — not demos that look good in a pitch deck.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group relative rounded-xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-blue-600/5"
            >
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600/10 to-purple-600/10">
                  <feature.icon className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
