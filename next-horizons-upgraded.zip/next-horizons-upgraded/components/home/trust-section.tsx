import { Quote } from "lucide-react"

const testimonials = [
  {
    quote: "Next Horizons rebuilt our entire client portal in three weeks. The new design increased demo bookings by 140% in the first month. Genuinely impressive execution.",
    author: "Chief Marketing Officer",
    company: "Series B SaaS company, Amsterdam",
    initials: "MV",
  },
  {
    quote: "What used to take our compliance team two days now takes twelve minutes. The CDD reports are thorough, structured, and audit-ready. This is the future of KYC.",
    author: "Head of Compliance",
    company: "Mid-size asset manager, Rotterdam",
    initials: "JB",
  },
  {
    quote: "We were sceptical about AI-generated designs, but the concepts they delivered felt hand-crafted. The attention to brand and conversion psychology was exceptional.",
    author: "Founder & CEO",
    company: "Fintech startup, The Hague",
    initials: "AL",
  },
]

const clientTypes = [
  "Banks & Credit Institutions",
  "Asset Managers",
  "Fintech Companies",
  "Law Firms",
  "Compliance Consultancies",
  "Scale-up SaaS",
]

export function TrustSection() {
  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

        {/* Client type bar */}
        <div className="text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Trusted across industries
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            {clientTypes.map((type) => (
              <span
                key={type}
                className="rounded-full border border-border/50 bg-foreground/[0.03] px-4 py-2 text-sm text-muted-foreground"
              >
                {type}
              </span>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mt-20">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Client Stories</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Real Results, Real Clients
            </h2>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm"
              >
                <Quote className="h-8 w-8 text-blue-600/20" />
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-600/20 to-purple-600/20 text-xs font-bold text-blue-700">
                    {t.initials}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{t.author}</p>
                    <p className="text-xs text-muted-foreground">{t.company}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
