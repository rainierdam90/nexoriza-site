import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Globe, Shield, ArrowRight, CheckCircle } from "lucide-react"

const services = [
  {
    icon: Globe,
    badge: "Website Redesign",
    title: "Turn Your Website Into a Growth Engine",
    description: "Your website is your hardest-working salesperson — yet most business websites repel visitors within 3 seconds. We use advanced AI to analyse your current site, craft a high-converting design, and build it on a blazing-fast modern stack.",
    bullets: [
      "AI-generated design concepts in 48 hours",
      "Built on Next.js for peak performance & SEO",
      "Conversion-optimised copy included",
      "Mobile-first, fully responsive",
    ],
    href: "/services/website-redesign",
    cta: "See how it works",
    gradient: "from-blue-600 to-blue-500",
    glowColor: "blue",
  },
  {
    icon: Shield,
    badge: "Due Diligence AI",
    title: "Compliance at the Speed of AI",
    description: "Manual due diligence is slow, expensive, and error-prone. Our AI performs deep OSINT research, screens against global sanctions lists, and delivers audit-ready CDD reports — in minutes, not days.",
    bullets: [
      "OSINT across 500+ public data sources",
      "CDD reports aligned with FATF & EU AML",
      "Real-time sanctions & PEP screening",
      "High-risk country & sector intelligence",
    ],
    href: "/services/due-diligence",
    cta: "Request a demo",
    gradient: "from-purple-600 to-purple-500",
    glowColor: "purple",
  },
]

export function ServicesSection() {
  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">What We Do</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Two Services. One Mission: Make AI Work For You.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Whether you need a website that converts or compliance workflows that scale — we build AI-powered solutions that deliver measurable results.
          </p>
        </div>

        {/* Service Cards */}
        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          {services.map((service) => (
            <div
              key={service.title}
              className="group relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-8 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-xl hover:shadow-blue-600/5"
            >
              {/* Glassmorphism glow effect */}
              <div className={`absolute -right-20 -top-20 h-56 w-56 rounded-full bg-gradient-to-br ${service.gradient} opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-10`} />
              
              <div className="relative">
                {/* Badge + Icon row */}
                <div className="flex items-center gap-3">
                  <div className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${service.gradient}`}>
                    <service.icon className="h-6 w-6 text-white" />
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold bg-gradient-to-r ${service.gradient} bg-clip-text text-transparent border border-border/50`}>
                    {service.badge}
                  </span>
                </div>

                {/* Content */}
                <h3 className="mt-6 text-xl font-semibold text-foreground leading-snug">
                  {service.title}
                </h3>
                <p className="mt-3 text-muted-foreground">
                  {service.description}
                </p>

                {/* Bullets */}
                <ul className="mt-5 space-y-2">
                  {service.bullets.map((b) => (
                    <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="h-4 w-4 shrink-0 text-blue-600" />
                      {b}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <Button
                  asChild
                  variant="ghost"
                  className="group/btn mt-6 -ml-4 text-foreground"
                >
                  <Link href={service.href}>
                    {service.cta}
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
