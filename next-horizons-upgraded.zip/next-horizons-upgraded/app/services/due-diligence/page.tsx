import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AnimatedBackground } from "@/components/animated-background"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { 
  ArrowRight, 
  Search, 
  FileText, 
  AlertTriangle, 
  Globe,
  UserSearch,
  Bell,
  Building2,
  Briefcase,
  Scale,
  CreditCard,
  Shield,
  CheckCircle,
  Lock,
  Clock,
  TrendingDown,
  Quote
} from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "AI-Powered Due Diligence Software | Next Horizons",
  description: "Automate KYC/AML compliance with AI-driven OSINT, CDD report generation, sanctions screening, and real-time regulatory intelligence. Built for financial institutions.",
}

const capabilities = [
  {
    icon: Search,
    title: "Deep OSINT Research",
    description: "Our AI scours 500+ public data sources — corporate registries, court records, news archives, social networks, and regulatory databases — to build a complete intelligence picture of any entity in minutes.",
  },
  {
    icon: FileText,
    title: "AI-Generated CDD Reports",
    description: "Receive structured, narrative-quality Customer Due Diligence reports ready for your compliance file. Each report follows your internal template and includes risk ratings, source citations, and recommended actions.",
  },
  {
    icon: AlertTriangle,
    title: "Sanctions List Screening",
    description: "Real-time screening against OFAC SDN, EU Consolidated, UN Security Council, UK HM Treasury, and 60+ other lists — with automated match scoring and escalation flags.",
  },
  {
    icon: Globe,
    title: "High-Risk Country & Sector Intelligence",
    description: "Stay ahead of FATF grey lists, EU high-risk third country updates, and sector-specific AML risks. Automatically flagged at entity review and in your daily briefing.",
  },
  {
    icon: UserSearch,
    title: "PEP & Adverse Media Screening",
    description: "Identify politically exposed persons and their associates, plus adverse media signals across 100+ languages — so nothing slips through in cross-border reviews.",
  },
  {
    icon: Bell,
    title: "Ongoing Monitoring & Alerts",
    description: "Set-and-forget monitoring on any entity in your portfolio. Receive instant alerts when sanctions, adverse news, or ownership changes occur — before your regulator asks.",
  },
]

const audiences = [
  {
    icon: Building2,
    title: "Banks & Credit Institutions",
    description: "Reduce your CDD backlog by 80% without adding headcount. Meet MiFID II, 6AMLD, and local AML obligations with audit-ready outputs your regulator will respect.",
  },
  {
    icon: Briefcase,
    title: "Asset Managers & Investment Firms",
    description: "Run enhanced due diligence on counterparties, fund investors, and acquisition targets faster than ever — without compromising on depth or accuracy.",
  },
  {
    icon: Scale,
    title: "Compliance & Legal Teams",
    description: "Stop spending 70% of your day on research. Let AI handle the OSINT and draft the report — while you focus on analysis, judgement, and high-value advisory work.",
  },
  {
    icon: CreditCard,
    title: "Fintechs & Payment Providers",
    description: "Scale your KYC operations without scaling your compliance team. Onboard clients faster, reduce friction, and stay ahead of your regulatory obligations.",
  },
]

const steps = [
  { step: "01", title: "Input Entity", description: "Provide a name, company registration number, or any identifier. Our AI resolves ambiguity automatically." },
  { step: "02", title: "AI Research", description: "Deep OSINT across 500+ sources runs in the background — corporate records, media, court filings, sanctions lists, and more." },
  { step: "03", title: "Risk Analysis", description: "Our models cross-reference findings, identify red flags, score risk levels, and flag regulatory triggers aligned to your risk appetite." },
  { step: "04", title: "Report Delivered", description: "A structured, audit-ready CDD report lands in your dashboard — with source links, confidence scores, and recommended actions." },
  { step: "05", title: "Ongoing Monitoring", description: "Your reviewed entities stay under 24/7 watch. Any material change triggers an instant alert so you're always one step ahead." },
]

const badges = [
  { icon: Shield, title: "GDPR Compliant", sub: "Data processed in EU" },
  { icon: CheckCircle, title: "Audit-Ready Output", sub: "Formatted for your compliance file" },
  { icon: Lock, title: "Bank-Grade Security", sub: "ISO 27001 aligned" },
  { icon: Globe, title: "FATF Aligned", sub: "Covers all 40 Recommendations" },
]

const faqs = [
  {
    q: "How does the system handle false positives in sanctions screening?",
    a: "Our matching algorithm uses entity disambiguation and confidence scoring to dramatically reduce false positives. Each potential match includes a detailed breakdown of match rationale, allowing your compliance officer to make an informed decision in seconds — not hours.",
  },
  {
    q: "Can the CDD reports be customised to our internal template?",
    a: "Yes. We onboard each client with a template configuration session. Your report structure, risk categories, language, and escalation thresholds are configured to match your existing processes — so adoption is seamless.",
  },
  {
    q: "Which languages does the adverse media screening cover?",
    a: "We cover adverse media in 100+ languages, with AI-powered translation and relevance scoring. Coverage includes major news databases, regional publications, and regulatory announcements.",
  },
  {
    q: "How does pricing work?",
    a: "We offer volume-based pricing per review, plus a monthly platform fee that includes monitoring for your existing portfolio. Contact us for a tailored quote based on your review volumes and entity types.",
  },
  {
    q: "Is the platform suitable for smaller compliance teams?",
    a: "Absolutely. The platform is designed to give a team of two the output capacity of a team of ten. There's no minimum volume requirement — we work with boutique asset managers and large banks alike.",
  },
]

export default function DueDiligencePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden pt-16">
          <AnimatedBackground />
          <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/50 bg-background/50 px-4 py-1.5 text-sm backdrop-blur-sm">
                <span className="h-2 w-2 rounded-full bg-purple-600 animate-pulse" />
                <span className="text-muted-foreground">AI-Powered Due Diligence</span>
              </div>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
                CDD That Used to Take{" "}
                <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  2 Days
                </span>{" "}
                Now Takes 12 Minutes
              </h1>
              <p className="mt-6 text-lg text-muted-foreground sm:text-xl">
                Our AI performs institutional-grade OSINT, screens against 60+ sanctions lists, and delivers audit-ready CDD reports — fully automated, fully documented, and aligned with FATF and EU AML standards.
              </p>
              <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
                <Button
                  asChild
                  size="lg"
                  className="group bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700"
                >
                  <Link href="/contact">
                    Request a Demo
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-border/50 bg-background/50 backdrop-blur-sm">
                  <Link href="/contact">Talk to a Compliance Expert</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="relative border-y border-border/50 bg-foreground/[0.01] py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 gap-8 text-center md:grid-cols-4">
              {[
                { value: "80%", label: "Reduction in research time" },
                { value: "500+", label: "OSINT sources covered" },
                { value: "60+", label: "Sanctions lists screened" },
                { value: "100+", label: "Languages for media screening" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent sm:text-4xl">
                    {stat.value}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Problem Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">The Compliance Challenge</p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                  Your Team Is Drowning in Research. There&apos;s a Better Way.
                </h2>
                <div className="mt-6 space-y-4 text-muted-foreground">
                  <p>
                    The regulatory environment has never been more complex. New sanctions regimes, expanding AML directives, and increasing scrutiny from regulators mean compliance teams are under more pressure than ever.
                  </p>
                  <p>
                    Yet the core process hasn&apos;t changed: a compliance officer opens a browser, searches company registries, reads news articles, checks sanctions lists manually — and spends two days on what a machine could do in minutes.
                  </p>
                  <p className="font-medium text-foreground">
                    We built the tool we wish existed. AI-native, built for financial services, and designed to make compliance teams more powerful — not redundant.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: Clock, label: "Average compliance officer spends 65% of time on manual research" },
                  { icon: TrendingDown, label: "Manual processes miss 23% of high-risk signals in adverse media" },
                  { icon: AlertTriangle, label: "Regulators issued record AML fines exceeding €5B in 2023" },
                  { icon: Globe, label: "New sanctions designations increased 300% since 2022" },
                ].map((item, i) => (
                  <div key={i} className="rounded-xl border border-border/50 bg-background/50 p-5">
                    <item.icon className="h-6 w-6 text-purple-600" />
                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Core Capabilities Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">Platform Capabilities</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Everything Your Compliance Team Needs in One Platform
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                From initial screening to ongoing monitoring — one integrated AI workflow.
              </p>
            </div>

            <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {capabilities.map((capability) => (
                <div
                  key={capability.title}
                  className="group relative overflow-hidden rounded-xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-purple-600/5"
                >
                  <div className="absolute -right-10 -top-10 h-24 w-24 rounded-full bg-gradient-to-br from-purple-600/10 to-blue-600/10 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
                  <div className="relative">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-purple-600 to-blue-600">
                      <capability.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-foreground">{capability.title}</h3>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{capability.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Who It's For Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">Who It&apos;s For</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Built for Organisations That Can&apos;t Afford to Miss a Flag
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                Our platform is used by compliance professionals across the financial services spectrum.
              </p>
            </div>

            <div className="mt-16 grid gap-8 md:grid-cols-2">
              {audiences.map((audience) => (
                <div
                  key={audience.title}
                  className="flex items-start gap-5 rounded-xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-blue-600/5"
                >
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-purple-600/10 to-blue-600/10">
                    <audience.icon className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">{audience.title}</h3>
                    <p className="mt-2 text-muted-foreground leading-relaxed">{audience.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">The Workflow</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                From Input to Insight in Under 15 Minutes
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                A fully automated pipeline — with your compliance officer in control at every step.
              </p>
            </div>

            <div className="mt-16 grid gap-6 md:grid-cols-5">
              {steps.map((step, index) => (
                <div key={step.step} className="relative">
                  {index < steps.length - 1 && (
                    <div className="absolute left-full top-10 hidden h-0.5 w-full bg-gradient-to-r from-purple-600/20 to-blue-600/20 md:block" style={{width: "calc(100% - 1.5rem)", left: "calc(50% + 1.5rem)"}} />
                  )}
                  <div className="rounded-xl border border-border/50 bg-background/50 p-6 text-center backdrop-blur-sm transition-all hover:border-border hover:shadow-lg hover:shadow-purple-600/5">
                    <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-blue-600 text-sm font-bold text-white">
                      {step.step}
                    </div>
                    <h3 className="mt-4 font-semibold text-foreground">{step.title}</h3>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonial */}
        <section className="relative py-24">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
            <Quote className="mx-auto h-10 w-10 text-purple-600/30" />
            <blockquote className="mt-6 text-2xl font-semibold leading-relaxed text-foreground sm:text-3xl">
              &ldquo;Our CDD review backlog went from three weeks to three days in the first month. The reports are more thorough than what we were producing manually — and our regulator reviewed them without a single question.&rdquo;
            </blockquote>
            <div className="mt-8 flex items-center justify-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-purple-600/20 to-blue-600/20 text-sm font-bold text-purple-700">
                SV
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground">Head of Compliance & MLRO</p>
                <p className="text-sm text-muted-foreground">Regional bank, Netherlands</p>
              </div>
            </div>
          </div>
        </section>

        {/* Trust & Compliance Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">Security & Compliance</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Built to the Standards You&apos;re Held To
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                Aligned with FATF 40 Recommendations, EU 6AMLD, and applicable local AML/CFT frameworks.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-4">
              {badges.map((badge) => (
                <div
                  key={badge.title}
                  className="flex flex-col items-center gap-3 rounded-xl border border-border/50 bg-background/50 px-5 py-6 text-center backdrop-blur-sm"
                >
                  <badge.icon className="h-8 w-8 text-purple-600" />
                  <span className="font-semibold text-foreground">{badge.title}</span>
                  <span className="text-xs text-muted-foreground">{badge.sub}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="relative py-24">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">FAQ</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Questions We Get Asked
              </h2>
            </div>
            <div className="mt-12 space-y-6">
              {faqs.map((faq, i) => (
                <div key={i} className="rounded-xl border border-border/50 bg-background/50 p-6">
                  <h3 className="flex items-start gap-3 font-semibold text-foreground">
                    <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-purple-600" />
                    {faq.q}
                  </h3>
                  <p className="mt-3 pl-8 text-muted-foreground leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative overflow-hidden py-24">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600 to-blue-600" />
          <div 
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
              backgroundSize: "32px 32px"
            }}
          />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                See It in Action on Your Own Entities
              </h2>
              <p className="mt-4 text-lg text-white/80">
                Book a live demo and we&apos;ll run a real CDD report on an entity of your choice — so you can judge the quality yourself.
              </p>
              <Button
                asChild
                size="lg"
                className="group mt-8 bg-white text-purple-600 hover:bg-white/90"
              >
                <Link href="/contact">
                  Book Your Demo
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
