import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AnimatedBackground } from "@/components/animated-background"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { 
  ArrowRight, 
  Search, 
  Sparkles, 
  Code2, 
  Rocket,
  Palette,
  Smartphone,
  BarChart3,
  FileText,
  Gauge,
  Database,
  Headphones,
  CheckCircle,
  TrendingUp,
  Clock,
  Quote
} from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "AI-Powered Website Redesign | Next Horizons",
  description: "Transform your digital presence with cutting-edge AI-driven design. We create stunning, high-performance websites that captivate your audience and drive measurable conversions.",
}

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Discovery & Audit",
    description: "We start with a deep dive into your existing website, your competitors, and your customers. We analyse user behaviour data, conversion bottlenecks, and brand positioning — giving us the intel to design something truly better.",
  },
  {
    icon: Sparkles,
    step: "02",
    title: "AI-Powered Design",
    description: "Using the latest generative design tools, we create multiple high-fidelity concepts tailored to your brand. You pick the direction. We refine it until it's exactly right. First concepts delivered within 48 hours.",
  },
  {
    icon: Code2,
    step: "03",
    title: "Modern Development",
    description: "We build your site on Next.js — the same stack used by Vercel, Loom, and Notion. Server-side rendering, edge caching, and clean architecture ensure your site is fast, secure, and built to last.",
  },
  {
    icon: Rocket,
    step: "04",
    title: "Launch & Grow",
    description: "We handle deployment, DNS, and go-live. But we don't disappear after launch. We monitor performance, run A/B tests, and provide ongoing optimisation to keep your conversion rate climbing.",
  },
]

const features = [
  { icon: Palette, title: "Full Brand Redesign", description: "Every pixel aligned with your brand identity and target audience" },
  { icon: Smartphone, title: "Mobile-First Design", description: "Over 60% of web traffic is mobile — we build for it first" },
  { icon: BarChart3, title: "Conversion Optimisation", description: "Designed with psychology-backed CRO principles built in" },
  { icon: FileText, title: "AI Copywriting", description: "Persuasive, SEO-optimised copy generated and refined by AI" },
  { icon: Gauge, title: "Core Web Vitals 100", description: "Lightning-fast load times that Google rewards with higher rankings" },
  { icon: Database, title: "CMS Integration", description: "Update your content independently with Sanity, Contentful, or similar" },
  { icon: Headphones, title: "3 Months Post-Launch Support", description: "Bug fixes, tweaks, and performance monitoring included" },
]

const stats = [
  { value: "3×", label: "Average conversion uplift", sub: "across our redesign clients" },
  { value: "48h", label: "To first design concept", sub: "from signed brief" },
  { value: "<1s", label: "Target load time", sub: "on all devices" },
]

const faqs = [
  {
    q: "How long does a full redesign take?",
    a: "Most projects are completed in 4–8 weeks, depending on scope. We share the first design concepts within 48 hours of your brief being signed off.",
  },
  {
    q: "Do I need to provide content and copy?",
    a: "No. We use AI-assisted copywriting to draft all page copy based on your brand, audience, and goals. You review and approve. Photography and video we source or generate — you don't need to provide anything.",
  },
  {
    q: "Which technologies do you build on?",
    a: "We use Next.js, React, and Tailwind CSS for the frontend. For CMS, we typically recommend Sanity or Contentful. Hosting is on Vercel or your preferred provider.",
  },
  {
    q: "What if I want changes after launch?",
    a: "We include 3 months of post-launch support in every project. After that, we offer flexible monthly retainers for ongoing optimisation and updates.",
  },
]

export default function WebsiteRedesignPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden pt-16">
          <AnimatedBackground />
          <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/50 bg-background/50 px-4 py-1.5 text-sm backdrop-blur-sm">
                <span className="h-2 w-2 rounded-full bg-blue-600" />
                <span className="text-muted-foreground">AI-Powered Website Redesign</span>
              </div>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
                Your Website Is Either{" "}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Winning or Losing
                </span>{" "}
                Customers Right Now
              </h1>
              <p className="mt-6 text-lg text-muted-foreground sm:text-xl">
                The average visitor decides whether to stay or leave in 3 seconds. We use advanced AI to design websites that capture attention, build trust, and convert — the first time, every time.
              </p>
              <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
                <Button
                  asChild
                  size="lg"
                  className="group bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700"
                >
                  <Link href="/contact">
                    Start Your Redesign
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-border/50 bg-background/50 backdrop-blur-sm">
                  <Link href="/contact">Book a Free Audit</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="relative py-16 border-y border-border/50 bg-foreground/[0.01]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-3 gap-8 text-center">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent sm:text-5xl">
                    {stat.value}
                  </div>
                  <p className="mt-1 font-medium text-foreground">{stat.label}</p>
                  <p className="text-sm text-muted-foreground">{stat.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Problem Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">The Problem</p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                  Most Business Websites Are Silently Killing Sales
                </h2>
                <div className="mt-6 space-y-4 text-muted-foreground">
                  <p>
                    You invested in a website years ago. It looked great — then. But your market has moved on, your competitors have levelled up, and your customers expect more.
                  </p>
                  <p>
                    Slow load times, confusing navigation, copy that talks about you instead of your customer, and a design that screams &ldquo;2017&rdquo; — these are silent conversion killers that cost you real money every single day.
                  </p>
                  <p className="font-medium text-foreground">
                    We fix all of that. Using AI that understands design trends, user psychology, and SEO — and a team that knows how to turn insights into results.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: TrendingUp, label: "53% of users abandon a site that takes over 3s to load" },
                  { icon: Clock, label: "You have ~3 seconds to make a first impression" },
                  { icon: BarChart3, label: "A 1-second improvement in load time can increase conversions by 7%" },
                  { icon: Smartphone, label: "61% of users won't return to a mobile site they had trouble with" },
                ].map((item, i) => (
                  <div key={i} className="rounded-xl border border-border/50 bg-background/50 p-5">
                    <item.icon className="h-6 w-6 text-blue-600" />
                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Our Process</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                From Brief to Live in 4–8 Weeks
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                A streamlined, transparent process — so you always know what happens next.
              </p>
            </div>

            <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              {steps.map((step, index) => (
                <div key={step.title} className="group relative">
                  {index < steps.length - 1 && (
                    <div className="absolute left-1/2 top-12 hidden h-0.5 w-full bg-gradient-to-r from-blue-600/20 to-purple-600/20 lg:block" />
                  )}
                  <div className="relative rounded-xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-blue-600/5">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-purple-600">
                        <step.icon className="h-6 w-6 text-white" />
                      </div>
                      <span className="text-sm font-medium text-muted-foreground">{step.step}</span>
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-foreground">{step.title}</h3>
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* What's Included Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Everything Included</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                No Surprises. No Extras.
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                Every redesign project includes everything you need to launch and grow — from day one.
              </p>
            </div>

            <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className="flex items-start gap-4 rounded-xl border border-border/50 bg-background/50 p-5 backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-blue-600/5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600/10 to-purple-600/10">
                    <feature.icon className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{feature.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonial */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
            <Quote className="mx-auto h-10 w-10 text-blue-600/30" />
            <blockquote className="mt-6 text-2xl font-semibold leading-relaxed text-foreground sm:text-3xl">
              &ldquo;We&apos;d been putting off a redesign for two years. Next Horizons delivered in six weeks. Our homepage conversion rate went from 1.8% to 5.4%. That&apos;s not a small number when you&apos;re spending on ads.&rdquo;
            </blockquote>
            <div className="mt-8 flex items-center justify-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-600/20 to-purple-600/20 text-sm font-bold text-blue-700">
                RD
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground">Head of Growth</p>
                <p className="text-sm text-muted-foreground">B2B SaaS company, Amsterdam</p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">FAQ</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Common Questions
              </h2>
            </div>
            <div className="mt-12 space-y-6">
              {faqs.map((faq, i) => (
                <div key={i} className="rounded-xl border border-border/50 bg-background/50 p-6">
                  <h3 className="flex items-start gap-3 font-semibold text-foreground">
                    <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-blue-600" />
                    {faq.q}
                  </h3>
                  <p className="mt-3 pl-8 text-muted-foreground leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative overflow-hidden py-24">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-600" />
          <div 
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
              backgroundSize: "32px 32px"
            }}
          />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Your Next Client Is Googling You Right Now
              </h2>
              <p className="mt-4 text-lg text-white/80">
                Make sure what they find converts them. Book a free 30-minute website audit — no obligation, genuine value.
              </p>
              <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
                <Button asChild size="lg" className="group bg-white text-blue-600 hover:bg-white/90">
                  <Link href="/contact">
                    Book Free Audit
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white/30 bg-white/10 text-white hover:bg-white/20">
                  <Link href="/contact">Start Your Redesign</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
