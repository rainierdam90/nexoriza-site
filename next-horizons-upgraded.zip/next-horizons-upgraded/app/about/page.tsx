import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AnimatedBackground } from "@/components/animated-background"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { 
  ArrowRight, 
  Linkedin,
  Lightbulb,
  Heart,
  Target,
  Users
} from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About Us | Next Horizons",
  description: "A team of AI specialists, designers, and compliance experts based in Amsterdam — on a mission to make next-generation AI solutions accessible to every serious business.",
}

const team = [
  {
    name: "Alex Morgan",
    role: "CEO & Co-Founder",
    bio: "Former product lead at a major European fintech. Obsessed with the intersection of AI and business value. Speaks at financial services conferences on AI-driven compliance.",
    linkedin: "https://linkedin.com",
    initials: "AM",
  },
  {
    name: "Sara Visser",
    role: "Head of AI & Technology",
    bio: "PhD in computational linguistics. Built NLP systems for two exits before joining Next Horizons. Leads all model development, OSINT architecture, and AI product strategy.",
    linkedin: "https://linkedin.com",
    initials: "SV",
  },
  {
    name: "James Chen",
    role: "Head of Compliance Solutions",
    bio: "15 years in financial services compliance, including senior AML roles at two top-10 European banks. Ensures every CDD output meets the standard regulators actually expect.",
    linkedin: "https://linkedin.com",
    initials: "JC",
  },
  {
    name: "Maria Santos",
    role: "Creative & Design Director",
    bio: "Award-winning UX designer with a conversion-first philosophy. Has led redesigns for brands from pre-seed startups to FTSE 250 companies. Believes design should sell.",
    linkedin: "https://linkedin.com",
    initials: "MS",
  },
]

const values = [
  {
    icon: Lightbulb,
    title: "Innovation Without Buzzwords",
    description: "We use AI because it genuinely produces better results — not because it's a trend. Every tool and model we deploy has a specific, measurable reason for being there.",
  },
  {
    icon: Heart,
    title: "Trust Is Non-Negotiable",
    description: "In compliance, trust is everything. We are transparent about how our AI works, what it can do, and where human judgement should prevail.",
  },
  {
    icon: Target,
    title: "Results Over Reports",
    description: "We measure ourselves by the outcomes we create for clients — conversion rates, CDD turnaround times, and regulatory findings — not hours billed.",
  },
  {
    icon: Users,
    title: "True Partnership",
    description: "We don't disappear after delivery. We sit alongside your team, understand your context, and stay invested in your success long after go-live.",
  },
]

const milestones = [
  { year: "2022", event: "Founded in Amsterdam with a focus on AI for financial services compliance" },
  { year: "2023", event: "Launched our first AI-generated CDD platform; onboarded 8 financial institutions in year one" },
  { year: "2024", event: "Expanded into AI website redesign; first 100 clients across 12 countries" },
  { year: "2025", event: "Recognised as one of the Netherlands' fastest-growing AI companies" },
]

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden pt-16">
          <AnimatedBackground />
          <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/50 bg-background/50 px-4 py-1.5 text-sm backdrop-blur-sm">
                <span className="h-2 w-2 rounded-full bg-gradient-to-r from-blue-600 to-purple-600" />
                <span className="text-muted-foreground">Our Story</span>
              </div>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
                We Built the AI Tools{" "}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  We Wished Existed
                </span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground sm:text-xl">
                Next Horizons was born from frustration. Frustration with compliance tools that were outdated before they shipped, and websites that looked expensive but converted no one. We decided to build something better.
              </p>
            </div>
          </div>
        </section>

        {/* Mission & Vision Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2">
              <div className="relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-8 backdrop-blur-sm lg:p-12">
                <div className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-gradient-to-br from-blue-600/10 to-transparent blur-3xl" />
                <div className="relative">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-blue-600">Our Mission</h2>
                  <p className="mt-4 text-2xl font-semibold leading-relaxed text-foreground sm:text-3xl">
                    To make serious AI — the kind that actually changes outcomes — accessible to every ambitious business.
                  </p>
                  <p className="mt-4 text-muted-foreground leading-relaxed">
                    The best AI tools have historically been available only to companies with the budget for a dedicated data science team. We change that. Whether you&apos;re a 10-person compliance team or a 500-person bank, you deserve AI that works.
                  </p>
                </div>
              </div>

              <div className="relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-8 backdrop-blur-sm lg:p-12">
                <div className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-gradient-to-br from-purple-600/10 to-transparent blur-3xl" />
                <div className="relative">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-purple-600">Our Vision</h2>
                  <p className="mt-4 text-2xl font-semibold leading-relaxed text-foreground sm:text-3xl">
                    A world where compliance and digital performance are competitive advantages — not burdens.
                  </p>
                  <p className="mt-4 text-muted-foreground leading-relaxed">
                    We envision a future where any business can launch a world-class digital presence in days, and any compliance team can process due diligence reviews in minutes — with the confidence of a team ten times their size.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="relative py-24">
          <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">Our Journey</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                From Idea to Impact
              </h2>
            </div>
            <div className="mt-12 space-y-6">
              {milestones.map((m) => (
                <div key={m.year} className="flex gap-6">
                  <div className="flex flex-col items-center">
                    <div className="flex h-10 w-16 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 text-sm font-bold text-white">
                      {m.year}
                    </div>
                    <div className="mt-2 flex-1 w-px bg-border/50" />
                  </div>
                  <div className="pb-6 pt-2">
                    <p className="text-muted-foreground leading-relaxed">{m.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="relative bg-foreground/[0.02] py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-blue-600">The Team</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Operators, Not Theorists
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                Every person on this team has built products, run compliance functions, or shipped AI systems at scale. We know what good looks like — because we&apos;ve done the work.
              </p>
            </div>

            <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {team.map((member) => (
                <div
                  key={member.name}
                  className="group relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-6 text-center backdrop-blur-sm transition-all duration-300 hover:border-border hover:shadow-lg hover:shadow-blue-600/5"
                >
                  <div className="mx-auto h-20 w-20 overflow-hidden rounded-full bg-gradient-to-br from-blue-600/20 to-purple-600/20">
                    <div className="flex h-full w-full items-center justify-center text-xl font-bold text-blue-700">
                      {member.initials}
                    </div>
                  </div>
                  
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{member.name}</h3>
                  <p className="mt-0.5 text-sm font-medium text-blue-600">{member.role}</p>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{member.bio}</p>
                  
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-5 inline-flex items-center justify-center rounded-lg p-2 text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground"
                    aria-label={`${member.name}'s LinkedIn`}
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="relative py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-sm font-semibold uppercase tracking-wider text-purple-600">How We Work</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                What We Stand For
              </h2>
              <p className="mt-4 text-lg text-muted-foreground">
                These aren&apos;t values on a poster. They&apos;re the standards we hold ourselves to in every client engagement.
              </p>
            </div>

            <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {values.map((value) => (
                <div
                  key={value.title}
                  className="rounded-xl border border-border/50 bg-background/50 p-6 backdrop-blur-sm transition-all hover:border-border hover:shadow-lg hover:shadow-blue-600/5"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-purple-600">
                    <value.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-foreground">{value.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative overflow-hidden py-24">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-600" />
          <div 
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
              backgroundSize: "32px 32px"
            }}
          />
          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Let&apos;s Build Something That Matters
              </h2>
              <p className="mt-4 text-lg text-white/80">
                We take on a limited number of new clients each quarter to ensure every project gets the attention it deserves. Book a call to see if we&apos;re a good fit.
              </p>
              <Button
                asChild
                size="lg"
                className="group mt-8 bg-white text-blue-600 hover:bg-white/90"
              >
                <Link href="/contact">
                  Start a Conversation
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
