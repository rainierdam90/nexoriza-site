"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AnimatedBackground } from "@/components/animated-background"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  Mail, 
  MapPin, 
  Calendar,
  Send,
  Clock,
  MessageSquare,
  CheckCircle
} from "lucide-react"
import { useState } from "react"

const contactInfo = [
  {
    icon: Mail,
    label: "Email us",
    value: "hello@nexthorizons.ai",
    sub: "We reply within 24 hours",
    href: "mailto:hello@nexthorizons.ai",
  },
  {
    icon: MapPin,
    label: "Based in",
    value: "Amsterdam, Netherlands",
    sub: "Serving clients globally",
    href: null,
  },
  {
    icon: Clock,
    label: "Response time",
    value: "Within 24 hours",
    sub: "Monday to Friday",
    href: null,
  },
]

const reasons = [
  "Free website audit — we&apos;ll tell you exactly what&apos;s costing you conversions",
  "Live due diligence demo — we&apos;ll run a real report on an entity of your choice",
  "Scoping call for a redesign project",
  "Questions about pricing or timelines",
]

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden pt-16">
          <AnimatedBackground />
          <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border/50 bg-background/50 px-4 py-1.5 text-sm backdrop-blur-sm">
                <span className="h-2 w-2 rounded-full bg-gradient-to-r from-blue-600 to-purple-600" />
                <span className="text-muted-foreground">Get in Touch</span>
              </div>
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
                Let&apos;s See If We&apos;re a{" "}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Good Fit
                </span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground">
                No hard sell. No commitment required. Just an honest conversation about what you need and whether we can deliver it.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="relative pb-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2">
              {/* Left: Contact Info */}
              <div className="lg:pr-8">
                <h2 className="text-2xl font-semibold text-foreground">Good Reasons to Reach Out</h2>
                <ul className="mt-6 space-y-3">
                  {reasons.map((r, i) => (
                    <li key={i} className="flex items-start gap-3 text-muted-foreground">
                      <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-blue-600" />
                      <span dangerouslySetInnerHTML={{ __html: r }} />
                    </li>
                  ))}
                </ul>

                <div className="mt-10 space-y-6">
                  {contactInfo.map((info) => (
                    <div key={info.label} className="flex items-start gap-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600/10 to-purple-600/10">
                        <info.icon className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{info.label}</p>
                        {info.href ? (
                          <a href={info.href} className="font-medium text-foreground transition-colors hover:text-blue-600">
                            {info.value}
                          </a>
                        ) : (
                          <p className="font-medium text-foreground">{info.value}</p>
                        )}
                        <p className="text-xs text-muted-foreground">{info.sub}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Book a Call */}
                <div className="mt-10 rounded-xl border border-border/50 bg-gradient-to-br from-blue-600/5 to-purple-600/5 p-6">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                    <h3 className="font-semibold text-foreground">Prefer to talk?</h3>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Book a free 30-minute intro call. We&apos;ll listen to your situation and give you honest advice — whether that leads to working together or not.
                  </p>
                  <Button
                    variant="outline"
                    className="mt-4 gap-2 border-border/50 bg-background/50 backdrop-blur-sm hover:bg-background/80"
                  >
                    <Calendar className="h-4 w-4" />
                    Book a 30-Min Call
                  </Button>
                </div>
              </div>

              {/* Right: Form */}
              <div className="relative overflow-hidden rounded-2xl border border-border/50 bg-background/50 p-8 backdrop-blur-sm">
                <div className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-gradient-to-br from-blue-600/10 to-purple-600/10 blur-3xl" />
                
                {isSubmitted ? (
                  <div className="relative flex h-full flex-col items-center justify-center py-12 text-center">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-600 to-purple-600">
                      <Send className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="mt-6 text-xl font-semibold text-foreground">Message Sent — Thank You!</h3>
                    <p className="mt-3 max-w-sm text-muted-foreground">
                      We&apos;ll review your message and get back to you within 24 hours. If your enquiry is time-sensitive, feel free to book a call directly.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-6"
                      onClick={() => setIsSubmitted(false)}
                    >
                      Send Another Message
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="relative space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">Send Us a Message</h3>
                      <p className="mt-1 text-sm text-muted-foreground">Fill in the form and we&apos;ll be in touch within one business day.</p>
                    </div>

                    <div className="grid gap-6 sm:grid-cols-2">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-medium text-foreground">
                          Full Name *
                        </label>
                        <Input
                          id="name"
                          name="name"
                          placeholder="Your full name"
                          required
                          className="border-border/50 bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="company" className="text-sm font-medium text-foreground">
                          Company
                        </label>
                        <Input
                          id="company"
                          name="company"
                          placeholder="Your company name"
                          className="border-border/50 bg-background/50"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium text-foreground">
                        Work Email *
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="you@company.com"
                        required
                        className="border-border/50 bg-background/50"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="service" className="text-sm font-medium text-foreground">
                        What can we help with?
                      </label>
                      <Select name="service">
                        <SelectTrigger className="border-border/50 bg-background/50">
                          <SelectValue placeholder="Select a topic" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="website-redesign">Website Redesign</SelectItem>
                          <SelectItem value="website-audit">Free Website Audit</SelectItem>
                          <SelectItem value="due-diligence">Due Diligence Platform</SelectItem>
                          <SelectItem value="demo">Request a Demo</SelectItem>
                          <SelectItem value="pricing">Pricing & Availability</SelectItem>
                          <SelectItem value="other">Something Else</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium text-foreground">
                        Tell Us About Your Situation *
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        placeholder="What are you trying to solve? The more context you give, the better we can help."
                        rows={5}
                        required
                        className="border-border/50 bg-background/50 resize-none"
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700"
                    >
                      {isSubmitting ? "Sending..." : "Send Message"}
                    </Button>
                    <p className="text-center text-xs text-muted-foreground">
                      By submitting, you agree to our privacy policy. We never share your information.
                    </p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
